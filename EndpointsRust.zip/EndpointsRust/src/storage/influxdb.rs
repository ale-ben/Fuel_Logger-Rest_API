use std;
use influxdb2::{Client, RequestError};
use rocket::async_stream::stream;
use rocket::futures::stream;
use rocket::yansi::Paint;
use crate::types::fuel_structs::NewFuelLogStruct;


pub fn init_client() -> Client {
    let host: String = std::env::var("INFLUXDB_HOST").unwrap();
    let org: String = std::env::var("INFLUXDB_ORG").unwrap();
    let token: String = std::env::var("INFLUXDB_TOKEN").unwrap();
    Client::new(host, org, token)
}
pub async fn save_log(client: &Client, new_log: NewFuelLogStruct) -> Result<(), RequestError>{
    let bucket: String = std::env::var("INFLUXDB_BUCKET").unwrap();
    client.write(bucket.as_str(), stream::iter(vec![new_log])).await
}