use chrono::{DateTime, Local, TimeZone, Utc};
use influxdb2::FromDataPoint;
use influxdb2_derive::WriteDataPoint;
use rocket::serde::{Deserialize, Serialize};
use rocket::{get, serde::json::Json};
use rocket_okapi::okapi::schemars;
use rocket_okapi::okapi::schemars::JsonSchema;
use rocket_okapi::openapi;

#[derive(Serialize, Deserialize, JsonSchema, Default, WriteDataPoint)]
#[measurement = "FuelLog"]
#[serde(rename_all = "camelCase")]
pub struct NewFuelLogStruct {
    #[influxdb(timestamp)]
    pub date: i64,
    #[influxdb(field)]
    pub amount: f64,
    #[influxdb(field)]
    pub cost: f64,
    #[influxdb(field)]
    pub odometer: f64,
    #[influxdb(tag)]
    pub composite_log: Option<String>,
    #[influxdb(tag)]
    pub flagged: Option<String>
}