use influxdb2::Client;

pub struct EndpointsState {
    pub client: Client
}