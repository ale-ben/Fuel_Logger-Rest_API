use std::os::macos::raw::stat;
use rocket::{get, post, State};
use rocket::log::private::log;
use rocket_okapi::openapi;
use serde::{Deserialize, Serialize};
use log::warn;
use rocket::serde::json::Json;
use crate::storage::influxdb::save_log;
use crate::types::endpoints_state::EndpointsState;

use crate::types::fuel_structs::{NewFuelLogStruct};

#[openapi(tag = "Logs")]
#[get("/logs/all")]
pub fn get_logs() -> Json<Vec<NewFuelLogStruct>> {
    Json(vec![
        NewFuelLogStruct {
            date: Default::default(),
            amount: 0.0,
            cost: 0.0,
            odometer: 0.0,
            composite_log: None,
            flagged: None,
        },
        NewFuelLogStruct {
            date: Default::default(),
            amount: 0.0,
            cost: 0.0,
            odometer: 0.0,
            composite_log: None,
            flagged: Some("true".parse().unwrap()),
        },
    ])
}

#[openapi(tag = "Logs")]
#[get("/logs/<log_id>")]
pub fn get_log(log_id: i32) -> Json<Option<NewFuelLogStruct>> {
    Json(Some(NewFuelLogStruct {
        date: Default::default(),
        amount: 0.0,
        cost: 0.0,
        odometer: 0.0,
        composite_log: None,
        flagged: Some("false".parse().unwrap()),
    }))
}

#[openapi(tag="Logs")]
#[post("/logs/new", format="json", data = "<log>")]
pub async fn new_log(state: &State<EndpointsState>, log: Json<NewFuelLogStruct>) {
    save_log(&state.client, log.into_inner())
        .await
        .expect("Unable to save new log");
}